import ScopeOnePage from "@/components/environment/scope-one-page-layout"

export default function ScopeOneContent() {
  return <ScopeOnePage />
}
