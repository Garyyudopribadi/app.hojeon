 'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useAuth } from '../../lib/useAuth'
import { User, LogOut, Flame, Zap, FlaskConical, Building, Ambulance, Leaf, FileText, Info } from 'lucide-react'
import { Button } from '../../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '../../components/ui/dropdown-menu'
// auth handled by `useAuth`

  const menuItems = [
    { title: 'Facility', description: 'Information of Business Site', icon: Info, path: '/compliance/information' },
  { title: 'Fire Safety', description: 'Manage fire safety Management', icon: Flame, path: null },
  { title: 'Electrical Safety', description: 'Electrical safety Management', icon: Zap, path: null },
  { title: 'Chemical', description: 'Chemical handling Management', icon: FlaskConical, path: null },
  { title: 'Building Safety', description: 'Building safety', icon: Building, path: null },
  { title: 'First Aid Kit', description: 'First aid kit Data Management', icon: Ambulance, path: null },
  { title: 'Environment', description: 'Environmental Data Management', icon: Leaf, path: '/compliance/environment' },
  { title: 'Document Control', description: 'Document management', icon: FileText, path: null },
]

export default function DashboardPage() {
  const [currentTime, setCurrentTime] = useState(new Date())
  const [entity, setEntity] = useState('ENTITY NAME')
  const [nickname, setNickname] = useState('User Name')
  const [loadingLocal, setLoadingLocal] = useState(true)
  const router = useRouter()
  const { loading, profile } = useAuth()

  useEffect(() => {
    if (!loading) {
      // populate entity and nickname from profile
      if (profile) {
        setEntity(profile.entity || 'PT.YONGJIN JAVASUKA GARMENT')
        setNickname(profile.nickname || 'Gary Yudo')
      }
      setLoadingLocal(false)

      // department guard: if user's department exists and is not 'compliance', redirect
      const dept = profile?.department ? String(profile.department).toLowerCase() : null
      if (dept && dept !== 'compliance') {
        const safeDept = dept.replace(/[^a-z0-9-_/]/gi, '').replace(/^\/+|\/+$/g, '')
        router.push('/' + safeDept)
      }
    }
  }, [loading, profile, router])

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push('/')
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    })
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    })
  }

  return (
    <>
      {(loading || loadingLocal) ? (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900 mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading...</p>
          </div>
        </div>
      ) : (
        <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white/70 backdrop-blur-xl shadow-sm border-b border-gray-200/50 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-10">
          <div className="flex justify-between items-center py-6">
            <div className="space-y-1">
              <h1 className="text-2xl font-semibold text-gray-900 tracking-tight">
                {entity}
              </h1>
              <p className="text-sm text-gray-500 font-medium" suppressHydrationWarning>
                {formatDate(currentTime)} • {formatTime(currentTime)}
              </p>
            </div>
            <div className="flex items-center space-x-3">
              <span className="text-sm font-medium text-gray-700">{nickname}</span>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-10 w-10 rounded-full hover:bg-gray-100/50 transition-all duration-200 active:scale-95">
                    <User className="h-5 w-5 text-gray-700" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56 bg-white/95 backdrop-blur-xl border-gray-200/50 shadow-xl rounded-2xl" align="end" forceMount>
                  <DropdownMenuItem className="hover:bg-gray-50/80 transition-colors rounded-xl mx-1 my-0.5">
                    <User className="mr-3 h-4 w-4 text-gray-600" />
                    <span className="font-medium text-gray-900">Profile</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="hover:bg-gray-50/80 transition-colors rounded-xl mx-1 my-0.5" onClick={handleLogout}>
                    <LogOut className="mr-3 h-4 w-4 text-gray-600" />
                    <span className="font-medium text-gray-900">Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl mx-auto py-16 px-6 sm:px-8 lg:px-10">
        {/* Page Header */}
        <div className="text-center mb-12">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">
            Management System
          </h1>
          <p className="text-gray-600 text-sm md:text-base">
            Select a module to manage your compliance and safety operations
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {menuItems.map((item, index) => {
            const IconComponent = item.icon
            const cardContent = (
              <Card className="group relative overflow-hidden bg-white/80 backdrop-blur-sm border border-gray-200/50 shadow-sm hover:shadow-xl hover:bg-white transition-all duration-300 cursor-pointer rounded-2xl hover:scale-[1.02] active:scale-[0.98] min-h-[140px] flex flex-col">
                <CardHeader className="pb-4 pt-6">
                  <div className="flex items-center space-x-4">
                    <div className="p-3 rounded-xl bg-gray-100/80 shadow-sm group-hover:bg-gray-200/80 group-hover:shadow-md transition-all duration-300">
                      <IconComponent className="h-7 w-7 text-gray-700" />
                    </div>
                    <CardTitle className="text-lg font-semibold text-gray-900 group-hover:text-gray-800 transition-colors leading-tight">
                      {item.title}
                    </CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="pt-0 flex-1 flex items-start">
                  <CardDescription className="text-gray-600 group-hover:text-gray-500 transition-colors text-sm leading-relaxed">
                    {item.description}
                  </CardDescription>
                </CardContent>
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-b-2xl" />
              </Card>
            )
            return item.path ? (
              <Link key={index} href={item.path}>
                {cardContent}
              </Link>
            ) : (
              <div key={index}>
                {cardContent}
              </div>
            )
          })}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white/70 backdrop-blur-xl border-t border-gray-200/50">
        <div className="max-w-7xl mx-auto py-8 px-6 sm:px-8 lg:px-10">
          <p className="text-center text-sm text-gray-600 font-medium">
            © 2025 PT.YONGJIN JAVASUKA GARMENT. All rights reserved. 
            <span className="text-gray-900 font-semibold ml-1">Developed by Garyyudo</span>
          </p>
        </div>
      </footer>
    </div>
    )}
  </>
  )
}